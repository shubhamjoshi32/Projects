﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GymMembers.WebAPI.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    Customer_Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Customer_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Customer_Age = table.Column<int>(type: "int", nullable: false),
                    Customer_Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Customer_PhNo = table.Column<long>(type: "bigint", nullable: false),
                    Customer_Height = table.Column<float>(type: "real", nullable: false),
                    Customer_Weight = table.Column<float>(type: "real", nullable: false),
                    Customer_Plan = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.Customer_Id);
                });

            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "Customer_Id", "Customer_Age", "Customer_Email", "Customer_Height", "Customer_Name", "Customer_PhNo", "Customer_Plan", "Customer_Weight" },
                values: new object[] { new Guid("d6478ddc-3404-492c-9bf7-7feea54149b7"), 89, "Shubham@gmail.com", 5.4f, "shubham", 9370110732L, "Yoga", 55f });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Customers");
        }
    }
}
