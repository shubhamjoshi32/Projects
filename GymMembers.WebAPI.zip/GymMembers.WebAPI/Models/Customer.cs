﻿using System.ComponentModel.DataAnnotations;

namespace GymMembers.WebAPI.Models
{
    public class Customer
    {
        [Key]
        public Guid Customer_Id { get; set; }
        public required string Customer_Name { get; set; }
        public int Customer_Age { get; set; }
        public required string Customer_Email { get; set; }
        public long Customer_PhNo { get; set; }
        public float Customer_Height { get; set; }
        public float Customer_Weight { get; set; }
        public string? Customer_Plan { get; set; }
    }
}
