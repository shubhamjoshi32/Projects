﻿using GymMembers.WebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace GymMembers.WebAPI.DatabaseContext
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {

        }
        public ApplicationDbContext()
        {

        }
        public virtual DbSet<Customer> Customers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Customer>().HasData(new Customer()
            {
                Customer_Id = Guid.Parse("D6478DDC-3404-492C-9BF7-7FEEA54149B7"),
                Customer_Name = "shubham",
                Customer_Age = 89,
                Customer_Email = "Shubham@gmail.com",
                Customer_PhNo = 9370110732,
                Customer_Height = 5.4F,
                Customer_Weight = 55F,
                Customer_Plan = "Yoga"
            });
        }
    }
}

